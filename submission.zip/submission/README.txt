my mainlab5 creates a few test files which show the different contributions.
photon mapping starts on line 283 in scene.cpp.
Can compile with: 
g++ -o "lab5.exe" "mainlab5.cpp" "framebuffer.cpp" "polymesh.cpp" "sphere.cpp" "phong.cpp" "directional_light.cpp" "point_light.cpp" "scene.cpp" "nanoflann-master/include/nanoflann.hpp" "-lm"

